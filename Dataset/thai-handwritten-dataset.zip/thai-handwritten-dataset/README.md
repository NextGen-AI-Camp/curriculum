# Thai Handwritten Dataset

This folder contains the Thai handwritten dataset from [kittinan/thai-handwriting-number](https://github.com/kittinan/thai-handwriting-number).
The dataset contains 1750 images of handwriting images from 0 to 9 in Thai digit character. We use the
dataset for a neural network classification task.
